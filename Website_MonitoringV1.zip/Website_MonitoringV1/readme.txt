Setup config.properties file
We have all the parameters defined in config file, which we can change as per the requirements.

1. url = The website url, which we need to monitor, we can input in url parameter.

2. recipientEmailIds = In this parameter we need to define the recipient Email Ids, those will get the notification. For more
than one recipient we need to use comma to separate values.

3. waitTimeInSeconds = We can define the time intervals to check the target website .

4. responseCodeThreshold = In this parameter, we can define the response code, above that we need to notify(example if we will
define 400, then we will get notification if our target website having response code 400 and more than that.

5. senderEmail = In this parameter we need to define the notification sender email id.

6. senderEmailPassword = This parameter you can leave blank in config.properties file and you can define password in encryptpassword 
batch file, it will automatically update "senderEmailPassword" parameter encrypted format in config.properties file.

After defining all the parameters in config.properties file, we can run the "MonitorWebsite" windows batch file to monitor the target website.
